package com.harsha.keypop.latin;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.HorizontalScrollView;

/**
 * Horizontal scroll strip for the toolbar row above the keyboard.
 *
 * Only claims the gesture once an actual horizontal drag is detected (past touch
 * slop). Earlier this disallowed intercept unconditionally on ACTION_DOWN, which
 * meant every touch that merely started inside this row - including a tap on a
 * button, or a finger that started here and dragged onto the keyboard below -
 * was immediately claimed by the scroll strip instead of being left alone. That
 * is very likely what broke swipe/drag gestures near the toolbar: this view
 * doesn't need to steal anything until it knows the user is actually scrolling it.
 */
public class ToolbarScrollView extends HorizontalScrollView {
    private float mStartX;
    private float mStartY;
    private int mTouchSlop;

    public ToolbarScrollView(Context context) {
        super(context);
        init(context);
    }

    public ToolbarScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ToolbarScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
        mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mStartX = ev.getX();
                mStartY = ev.getY();
                // Don't disallow intercept yet: we don't know if this is a scroll,
                // a tap on a button, or a drag meant for a view below us.
                break;
            case MotionEvent.ACTION_MOVE:
                float dx = Math.abs(ev.getX() - mStartX);
                float dy = Math.abs(ev.getY() - mStartY);
                if (dx > mTouchSlop && dx > dy && getParent() != null) {
                    // Now we know it's a genuine horizontal drag on this row: claim it.
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                break;
        }
        return super.onInterceptTouchEvent(ev);
    }
}
