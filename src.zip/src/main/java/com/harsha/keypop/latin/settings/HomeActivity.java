package com.harsha.keypop.latin.settings;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.harsha.keypop.R;

import java.util.List;

public class HomeActivity extends Activity {

    private static final int REQ_EXPORT = 1001;
    private static final int REQ_IMPORT = 1002;

    private TextView txtCharCount;
    private EditText edtTest;
    private View cardEnable;
    private View cardSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        txtCharCount = findViewById(R.id.txtCharCount);
        edtTest = findViewById(R.id.edtTest);
        cardEnable = findViewById(R.id.cardEnable);
        cardSelect = findViewById(R.id.cardSelect);

        setupCard(cardEnable, R.drawable.ic_home_power, "Enable", "Allow in settings", "");
        setupCard(cardSelect, R.drawable.ic_home_keyboard, "Select", "Set as default", "");
        setupCard(findViewById(R.id.cardThemes), R.drawable.ic_home_palette, "Themes", "Colors and style", "");
        setupCard(findViewById(R.id.cardLanguages), R.drawable.ic_home_language, "Languages", "Layouts", "");
        setupCard(findViewById(R.id.cardTouch), R.drawable.ic_home_sparkle, "Touch effect", "Coming soon", "");
        setupCard(findViewById(R.id.cardClips), R.drawable.ic_home_clipboard, "Clips store", "Coming soon", "");
        setupCard(findViewById(R.id.cardPrefs), R.drawable.ic_home_tune, "Preferences", "Typing options", "");
        setupCard(findViewById(R.id.cardSettings), R.drawable.ic_home_settings, "Settings", "All options", "");
        setupCard(findViewById(R.id.cardExport), R.drawable.ic_home_upload, "Export backup", "Save JSON file", "");
        setupCard(findViewById(R.id.cardImport), R.drawable.ic_home_download, "Import backup", "Restore from JSON", "");

        edtTest.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                txtCharCount.setText(s.length() + " characters");
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.btnTopSettings).setOnClickListener(v -> openLegacySettings());
        findViewById(R.id.btnMenu).setOnClickListener(v -> openLegacySettings());

        cardEnable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        cardSelect.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });

        findViewById(R.id.cardThemes).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)
                        .putExtra(SettingsActivity.EXTRA_SHOW_FRAGMENT,
                                AppearanceSettingsFragment.class.getName())));

        findViewById(R.id.cardLanguages).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)
                        .putExtra(SettingsActivity.EXTRA_SHOW_FRAGMENT,
                                LanguagesSettingsFragment.class.getName())));

        findViewById(R.id.cardPrefs).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)
                        .putExtra(SettingsActivity.EXTRA_SHOW_FRAGMENT,
                                PreferencesSettingsFragment.class.getName())));

        findViewById(R.id.cardSettings).setOnClickListener(v -> openLegacySettings());
        findViewById(R.id.cardTouch).setOnClickListener(v -> showComingSoon("Touch effect"));
        findViewById(R.id.cardClips).setOnClickListener(v -> showComingSoon("Clips store"));

        findViewById(R.id.cardExport).setOnClickListener(v -> startExport());
        findViewById(R.id.cardImport).setOnClickListener(v -> startImport());

        LocalStore.saveNow(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean enabled = isImeEnabled();
        boolean selected = isImeSelected();
        setupCard(cardEnable, R.drawable.ic_home_power, "Enable", "Allow in settings",
                enabled ? "On" : "Off");
        setupCard(cardSelect, R.drawable.ic_home_keyboard, "Select", "Set as default",
                selected ? "On" : "Off");
        LocalStore.touchLastOpen(this);
        LocalStore.saveNow(this);
    }

    private void startExport() {
        LocalStore.saveNow(this);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "keypop_backup.json");
        startActivityForResult(intent, REQ_EXPORT);
    }

    private void startImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/json", "text/plain", "application/octet-stream"});
        startActivityForResult(intent, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_EXPORT) {
            boolean ok = LocalStore.exportToUri(this, uri);
            Toast.makeText(this, ok ? "Backup saved" : "Export failed", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQ_IMPORT) {
            boolean ok = LocalStore.importFromUri(this, uri);
            if (ok) {
                Toast.makeText(this, "Settings restored. Re-open keyboard.", Toast.LENGTH_LONG).show();
                onResume();
            } else {
                Toast.makeText(this, "Import failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupCard(View card, int iconRes, String title, String subtitle, String badge) {
        if (card == null) return;
        ImageView i = card.findViewById(R.id.cardIcon);
        TextView t = card.findViewById(R.id.cardTitle);
        TextView s = card.findViewById(R.id.cardSubtitle);
        TextView b = card.findViewById(R.id.cardBadge);
        if (i != null) i.setImageResource(iconRes);
        if (t != null) t.setText(title);
        if (s != null) s.setText(subtitle);
        if (b != null) {
            b.setText(badge);
            if ("On".equals(badge)) {
                b.setTextColor(0xFF69F0AE);
            } else if ("Off".equals(badge)) {
                b.setTextColor(0xFF7A8BA3);
            }
        }
    }

    private void openLegacySettings() {
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void showComingSoon(String feature) {
        new AlertDialog.Builder(this)
                .setTitle(feature)
                .setMessage("Coming soon.\nThis feature is not ready yet.")
                .setPositiveButton("OK", null)
                .show();
    }

    private boolean isImeEnabled() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            List<InputMethodInfo> list = imm.getEnabledInputMethodList();
            for (InputMethodInfo info : list) {
                if (getPackageName().equals(info.getPackageName())) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private boolean isImeSelected() {
        try {
            String current = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.DEFAULT_INPUT_METHOD);
            return current != null && current.startsWith(getPackageName());
        } catch (Exception ignored) {}
        return false;
    }
}
