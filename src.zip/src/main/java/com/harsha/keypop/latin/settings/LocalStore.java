package com.harsha.keypop.latin.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import com.harsha.keypop.compat.PreferenceManagerCompat;
import com.harsha.keypop.keyboard.KeyboardTheme;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Map;

/**
 * Real-time backup of keyboard SharedPreferences to JSON.
 * Export / import so themes + settings restore after reinstall.
 *
 * Local mirror: filesDir/keypop_local.json
 */
public final class LocalStore {
    private static final String FILE = "keypop_local.json";
    private static final String META_VERSION = "keypop_backup_version";
    private static final int BACKUP_VERSION = 1;

    private LocalStore() {}

    /** Dump current SharedPreferences -> JSON object */
    public static JSONObject snapshotFromPrefs(Context context) {
        SharedPreferences prefs = PreferenceManagerCompat.getDeviceSharedPreferences(context);
        JSONObject json = new JSONObject();
        try {
            json.put(META_VERSION, BACKUP_VERSION);
            json.put("package", context.getPackageName());
            json.put("updatedAt", System.currentTimeMillis());

            JSONObject data = new JSONObject();
            Map<String, ?> all = prefs.getAll();
            for (Map.Entry<String, ?> e : all.entrySet()) {
                String key = e.getKey();
                Object val = e.getValue();
                if (val == null) continue;
                if (val instanceof Boolean || val instanceof Integer
                        || val instanceof Long || val instanceof Float
                        || val instanceof String) {
                    data.put(key, val);
                } else if (val instanceof Double) {
                    data.put(key, (Double) val);
                } else {
                    data.put(key, String.valueOf(val));
                }
            }
            if (!data.has(KeyboardTheme.KEYBOARD_THEME_KEY)) {
                data.put(KeyboardTheme.KEYBOARD_THEME_KEY,
                        Integer.toString(KeyboardTheme.DEFAULT_THEME_ID));
            }
            json.put("prefs", data);
        } catch (Exception ignored) {}
        return json;
    }

    /** Apply JSON prefs into SharedPreferences (keyboard will pick them up) */
    public static boolean applyToPrefs(Context context, JSONObject root) {
        try {
            JSONObject data = root.has("prefs") ? root.getJSONObject("prefs") : root;
            SharedPreferences prefs = PreferenceManagerCompat.getDeviceSharedPreferences(context);
            SharedPreferences.Editor editor = prefs.edit();

            java.util.Iterator<String> keys = data.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (META_VERSION.equals(key) || "package".equals(key) || "updatedAt".equals(key)) {
                    continue;
                }
                Object val = data.get(key);
                if (val instanceof Boolean) {
                    editor.putBoolean(key, (Boolean) val);
                } else if (val instanceof Integer) {
                    editor.putInt(key, (Integer) val);
                } else if (val instanceof Long) {
                    editor.putLong(key, (Long) val);
                } else if (val instanceof Float) {
                    editor.putFloat(key, (Float) val);
                } else if (val instanceof Double) {
                    editor.putFloat(key, ((Double) val).floatValue());
                } else if (val instanceof String) {
                    editor.putString(key, (String) val);
                } else if (val instanceof Number) {
                    editor.putString(key, String.valueOf(val));
                }
            }
            editor.apply();
            saveMirror(context, snapshotFromPrefs(context));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void saveNow(Context context) {
        saveMirror(context, snapshotFromPrefs(context));
    }

    public static void touchLastOpen(Context context) {
        try {
            JSONObject json = snapshotFromPrefs(context);
            json.put("lastOpenAt", System.currentTimeMillis());
            saveMirror(context, json);
        } catch (Exception ignored) {}
    }

    public static JSONObject loadMirror(Context context) {
        File file = new File(context.getFilesDir(), FILE);
        if (!file.exists()) {
            JSONObject snap = snapshotFromPrefs(context);
            saveMirror(context, snap);
            return snap;
        }
        FileInputStream in = null;
        try {
            in = new FileInputStream(file);
            byte[] buf = new byte[(int) file.length()];
            int n = in.read(buf);
            String raw = n > 0 ? new String(buf, 0, n, Charset.forName("UTF-8")) : "{}";
            return new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
        }
    }

    private static void saveMirror(Context context, JSONObject json) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File(context.getFilesDir(), FILE));
            out.write(json.toString(2).getBytes(Charset.forName("UTF-8")));
            out.flush();
        } catch (Exception ignored) {
        } finally {
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    public static boolean exportToUri(Context context, Uri uri) {
        OutputStream os = null;
        try {
            JSONObject json = snapshotFromPrefs(context);
            saveMirror(context, json);
            os = context.getContentResolver().openOutputStream(uri);
            if (os == null) return false;
            os.write(json.toString(2).getBytes(Charset.forName("UTF-8")));
            os.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (os != null) os.close(); } catch (Exception ignored) {}
        }
    }

    public static boolean importFromUri(Context context, Uri uri) {
        InputStream is = null;
        try {
            is = context.getContentResolver().openInputStream(uri);
            if (is == null) return false;
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is, Charset.forName("UTF-8")));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            JSONObject json = new JSONObject(sb.toString());
            return applyToPrefs(context, json);
        } catch (Exception e) {
            return false;
        } finally {
            try { if (is != null) is.close(); } catch (Exception ignored) {}
        }
    }
}
