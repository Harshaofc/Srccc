package com.harsha.keypop.latin;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.harsha.keypop.R;
import com.harsha.keypop.latin.settings.SettingsActivity;

public final class ToolbarHelper {
    private ToolbarHelper() {}

    public static void bind(final View inputView, final Context context) {
        if (inputView == null || context == null) return;

        final TextView lang = inputView.findViewById(R.id.btn_toolbar_lang);
        final View scroll = inputView.findViewById(R.id.keyboard_toolbar_scroll);

        if (lang != null) {
            lang.setOnClickListener(v -> {
                String t = lang.getText() != null ? lang.getText().toString() : "";
                lang.setText(t.equals("Si") ? "En" : "Si");
            });
        }

        soon(inputView, R.id.btn_toolbar_emoji, context, "Emoji");
        soon(inputView, R.id.btn_toolbar_font, context, "Fonts");
        soon(inputView, R.id.btn_toolbar_clips, context, "Clips");
        soon(inputView, R.id.btn_toolbar_ai, context, "AI");
        soon(inputView, R.id.btn_toolbar_mic, context, "Mic");
        soon(inputView, R.id.btn_toolbar_theme, context, "Themes");

        View.OnClickListener openSettings = v -> {
            try {
                Intent i = new Intent(context, SettingsActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            } catch (Exception e) {
                Toast.makeText(context, "Settings – Coming soon", Toast.LENGTH_SHORT).show();
            }
        };
        View menu = inputView.findViewById(R.id.btn_toolbar_menu);
        View settings = inputView.findViewById(R.id.btn_toolbar_settings);
        if (menu != null) menu.setOnClickListener(openSettings);
        if (settings != null) settings.setOnClickListener(openSettings);

        View collapse = inputView.findViewById(R.id.btn_toolbar_collapse);
        if (collapse != null && scroll != null) {
            collapse.setOnClickListener(v ->
                    scroll.setVisibility(
                            scroll.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        }
    }

    private static void soon(View root, int id, Context ctx, String name) {
        View v = root.findViewById(id);
        if (v != null) {
            v.setOnClickListener(x ->
                    Toast.makeText(ctx, name + " – Coming soon", Toast.LENGTH_SHORT).show());
        }
    }
}
